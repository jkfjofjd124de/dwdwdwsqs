rm vkopt_chrome.zip
./_zip_packer.py chrome vkopt_chrome.zip
