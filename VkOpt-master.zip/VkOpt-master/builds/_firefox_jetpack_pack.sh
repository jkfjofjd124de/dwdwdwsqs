rm vkopt_firefox_jetpack.xpi
./_zip_packer.py firefoxJetpack vkopt_firefox_jetpack.xpi
