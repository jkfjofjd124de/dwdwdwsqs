rm vkopt_webext.zip
./_zip_packer.py webext vkopt_webext.zip
