rm vkopt_firefox.xpi
./_zip_packer.py firefox vkopt_firefox.xpi
